package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

        public static final String DATABASENAME1 = "Asyad.db";
        public static final String TABLENAME1 = "Asyadusers";
        public static final String COL_1 = "ID", COL_2 = "FNAME", COL_3 = "LNAME", COL_4 = "PhoneNo";

        public DatabaseHelper(Context context)
        {
            super(context, DATABASENAME1, null, 1);
        }

        public void onCreate(SQLiteDatabase db)
        {
            db.execSQL("create table " + TABLENAME1 + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, FNAME TEXT, LNAME TEXT, PhoneNo TEXT) ");
        }

        @Override
        public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion)
        {
            database.execSQL("DROP TABLE IF EXISTS " + TABLENAME1);
            onCreate(database);
        }

        public boolean insertData(String Fname, String Lname, String PhoneNO)
        {
            SQLiteDatabase dbAsysad = this.getReadableDatabase();
            ContentValues CVAsyad = new ContentValues();
            CVAsyad.put(COL_2, Fname);
            CVAsyad.put(COL_3, Lname);
            CVAsyad.put(COL_4, PhoneNO);

            long result = dbAsysad.insert(TABLENAME1, null, CVAsyad);
            if (result == -1)
                return false;
            else
                return true;
        }

        public boolean updateData(String id, String Fname, String Lname, String PhoneNO)
        {
            SQLiteDatabase dbAsysad = this.getReadableDatabase();
            ContentValues CVAsyad = new ContentValues();
            CVAsyad.put(COL_1, id);
            CVAsyad.put(COL_2, Fname);
            CVAsyad.put(COL_3, Lname);
            CVAsyad.put(COL_4, PhoneNO);

            dbAsysad.update(TABLENAME1, CVAsyad, "ID=?", new String[]{id});

            return true;
        }

        public Integer deleteData(String ID)
        {
            SQLiteDatabase dbAsysad = this.getReadableDatabase();
            return dbAsysad.delete(TABLENAME1, "ID=?", new String[]{ID});
        }

        public Cursor getAllData()
        {
            SQLiteDatabase dbAsysad = this.getWritableDatabase();
            Cursor cursor = dbAsysad.rawQuery("select * from " + TABLENAME1, null);
            return cursor;
        }

}
