package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper mDb;
    EditText name, last, nu, id;
    Button b1, b2, b3, b4, b5;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDb = new DatabaseHelper(this);

        name = (EditText) findViewById(R.id.ed1);
        last = (EditText) findViewById(R.id.ed2);
        nu = (EditText) findViewById(R.id.ed3);
        id = (EditText) findViewById(R.id.idtext);

        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        b3 = (Button) findViewById(R.id.b3);
        b4 = (Button) findViewById(R.id.b4);
        b5 = (Button) findViewById(R.id.b5);

        addData();
        updateData();
        deleteData();
        viewData();
        clearData();
    }

    public void addData()
    {
        b1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                boolean
                        insert=mDb.insertData(name.getText().toString(),last.getText().toString(),nu.getText().toString());
                if(insert==true)
                    Toast.makeText(MainActivity.this, "Data Inserted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MainActivity.this,"Data not inserted",Toast.LENGTH_LONG).show();

            }
        });
    }

    public void updateData()
    {
        b2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                boolean update=mDb.updateData(id.getText().toString(), name.getText().toString(),last.getText().toString(),nu.getText().toString());
                if(update==true)
                    Toast.makeText(MainActivity.this,"Data updated",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MainActivity.this, "Data not updated",Toast.LENGTH_LONG).show();
            }
        });
    }

    public void deleteData()
    {
        b3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Integer del=mDb.deleteData(id.getText().toString());
                if(del>0)
                    Toast.makeText(MainActivity.this,"Data deleted",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(MainActivity.this,"Dat not deleted",Toast.LENGTH_LONG).show();
            }
        });
    }

    public void viewData()
    {
        b4.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Cursor view=mDb.getAllData();
                if(view.getCount()==0)
                {
                    showMessage("Error", "Nothing found");
                    return;
                }

                StringBuffer b=new StringBuffer();
                while(view.moveToNext())
                {
                    b.append("ID:"+view.getString(0)+"\n");
                    b.append("First name: "+view.getString(1)+"\n");
                    b.append("Last name: "+view.getString(2)+"\n");
                    b.append("Phone: "+view.getString(3)+"\n");
                }

                showMessage("Student Details",b.toString());

            }
        });
    }

    public void clearData()
    {
        b5.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                name.setText("");
                last.setText("");
                nu.setText("");
                id.setText("");

            }
        });
    }

    public void showMessage(String title,String mes)
    {
        AlertDialog.Builder ad=new AlertDialog.Builder(this);
        ad.setCancelable(true);
        ad.setTitle(title);
        ad.setMessage(mes);
        ad.show();
    }
}